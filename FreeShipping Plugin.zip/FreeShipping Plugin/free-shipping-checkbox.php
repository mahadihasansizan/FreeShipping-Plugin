<?php
/*
Plugin Name: Free Shipping Checkbox
Description: Adds a checkbox on the product page to enable free shipping.
Version: 1.0
Author: Mahadi 
*/

// Add checkbox on product page
add_action('woocommerce_before_single_product', 'add_free_shipping_checkbox');
function add_free_shipping_checkbox() {
    echo '<div class="free-shipping-checkbox">';
    woocommerce_form_field('enable_free_shipping', array(
        'type'    => 'checkbox',
        'label'   => __('Enable Free Shipping', 'free-shipping-checkbox'),
        'default' => 0,
    ), get_post_meta(get_the_ID(), 'enable_free_shipping', true));
    echo '</div>';
}

// Save checkbox state
add_action('woocommerce_process_product_meta', 'save_free_shipping_checkbox');
function save_free_shipping_checkbox($post_id) {
    $enable_free_shipping = isset($_POST['enable_free_shipping']) ? 'yes' : 'no';
    update_post_meta($post_id, 'enable_free_shipping', $enable_free_shipping);
}

// Apply free shipping based on checkbox
add_filter('woocommerce_package_rates', 'apply_free_shipping');
function apply_free_shipping($rates) {
    foreach ($rates as $rate_id => $rate) {
        if (get_post_meta(WC()->cart->get_cart()[0]['product_id'], 'enable_free_shipping', true) === 'yes') {
            if ($rate->method_id === 'flat_rate') {
                $rates[$rate_id]->cost = 0;
            }
        }
    }
    return $rates;
}
